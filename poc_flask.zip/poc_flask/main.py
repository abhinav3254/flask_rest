from flask import Flask, Response,jsonify, request
import database as db
import add_to_do as add
import csv
import io


app = Flask(__name__)


# add todo
@app.route('/add',methods=['POST'])
def add_to_do():
	user_data = request.json
	title = user_data.get('title')
	description = user_data.get('description')
	completed = user_data.get('completed')
	add.save_todo(title,description,completed)
	return 'added',201
	

# get all todo
@app.route('/')
def get_all_todo():
	connection = db.create_db_connection()
	cursor = connection.cursor()
	cursor.execute("SELECT * from public.todo;")
	all_todo = cursor.fetchall()
	formatted_data = [
        {
            "id": row[0],
            "title": row[1],
            "description": row[2],
            "completed": row[3],
            "created_date": row[4]
        }
        for row in all_todo
    ]

	return jsonify(formatted_data)
	
	

# update a todo
@app.route('/update', methods=['PUT'])
def update_a_todo():
    connection = db.create_db_connection()
    cursor = connection.cursor()
    user_data = request.json
    id = user_data.get('id')
    title = user_data.get('title')
    description = user_data.get('description')
    completed = user_data.get('completed')

    cursor.execute("SELECT * FROM todo WHERE id = %s", (id,))
    todo = cursor.fetchone()

    if not todo:
        cursor.close()
        connection.close()
        return jsonify({'message': 'Todo not found'}), 404 
	
    new_title = title if title is not None else todo[1]
    new_description = description if description is not None else todo[2]
    new_completed = completed if completed is not None else todo[3]

    update_query = '''UPDATE todo SET title = %s, description = %s, completed = %s WHERE id = %s'''
    cursor.execute(update_query, (new_title, new_description, new_completed, id))
    connection.commit()
    cursor.close()
    connection.close()
    return jsonify({'message': 'Todo updated'})
		
	

# delete by id
@app.route('/deleted/<int:id>', methods=['DELETE'])
def deleteToDo(id):
    connection = db.create_db_connection()
    cursor = connection.cursor()

    delete_query = '''DELETE FROM todo WHERE id = %s'''
    cursor.execute(delete_query, (id,))

    connection.commit()
    cursor.close()
    connection.close()

    return jsonify({'message': 'Todo Deleted'})

# export as csv
@app.route('/export-csv')
def export_csv():
    connection = db.create_db_connection()    
    cursor = connection.cursor()

    # Execute a SELECT query to retrieve all data from your table
    cursor.execute("SELECT * FROM public.todo")
    data = cursor.fetchall()

    # Define the response headers to specify a CSV content type
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "title", "description", "completed", "created_date"])

    for row in data:
        writer.writerow(row)

    response = Response(output.getvalue(), content_type='text/csv')
    response.headers['Content-Disposition'] = 'attachment; filename=todo.csv'

    # Close the cursor and the database connection
    cursor.close()
    connection.close()

    return response


# upload a csv file
@app.route('/upload-csv', methods=['GET', 'POST'])
def upload_csv():
    if request.method == 'POST':
        csv_file = request.files['csv_file']
        if csv_file:
            try:
                # Read the uploaded CSV file in text mode
                csv_data = csv.reader(csv_file.stream.read().decode("UTF-8").splitlines())
                next(csv_data)  # Skip the header row if it exists

                # Connect to the database
                connection = db.create_db_connection()
                cursor = connection.cursor()

                for row in csv_data:
                    # Convert "True" and "False" strings to actual boolean values
                    if row[3].lower() == "true":
                        completed = True
                    else:
                        completed = False
                    insert_query = "INSERT INTO todo(title, description,completed) VALUES (%s, %s, %s);"
                    cursor.execute(insert_query, (row[1], row[2], completed))

                # Commit the changes and close the database connection
                connection.commit()
                cursor.close()
                connection.close()

                return 'Data from CSV file has been saved to the database.'

            except Exception as e:
                return f'Error: {str(e)}'
        else:
            return 'No CSV file was provided.'


# main driver function
if __name__ == '__main__':
	app.run(debug=True)